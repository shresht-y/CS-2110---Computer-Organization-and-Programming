This game is loosely based off of the story of JOJO: Part 7.
The game represents a race, in which all racers are travelling a certain amount of meters per second (representing the progression in the game). 
The goal is to touch the flag before the other racers make it to the goal, at 1000m.

Controls:
ENTER: Start the game 
BACKSPACE: Reset the game 
W: Move Up
A: Move Left
S: Move Down
D: Move Right