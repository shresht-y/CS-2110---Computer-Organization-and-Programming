/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 End End.png 
 * Time-stamp: Monday 11/07/2022, 18:40:43
 * 
 * Image Information
 * -----------------
 * End.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef END_H
#define END_H

extern const unsigned short End[38400];
#define END_SIZE 76800
#define END_LENGTH 38400
#define END_WIDTH 240
#define END_HEIGHT 160

#endif

