/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=12x19 Flag Flag.png 
 * Time-stamp: Monday 11/07/2022, 04:07:17
 * 
 * Image Information
 * -----------------
 * Flag.png 12@19
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLAG_H
#define FLAG_H

extern const unsigned short Flag[228];
#define FLAG_SIZE 456
#define FLAG_LENGTH 228
#define FLAG_WIDTH 12
#define FLAG_HEIGHT 19

#endif

