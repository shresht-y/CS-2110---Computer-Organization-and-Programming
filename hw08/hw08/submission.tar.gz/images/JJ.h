/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=12x19 JJ JJ.png 
 * Time-stamp: Sunday 11/06/2022, 23:23:36
 * 
 * Image Information
 * -----------------
 * JJ.png 12@19
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JJ_H
#define JJ_H

extern const unsigned short JJ[228];
#define JJ_SIZE 456
#define JJ_LENGTH 228
#define JJ_WIDTH 12
#define JJ_HEIGHT 19

#endif

