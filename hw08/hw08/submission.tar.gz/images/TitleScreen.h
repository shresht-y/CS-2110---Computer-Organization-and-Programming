/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreen TitleScreen.png 
 * Time-stamp: Sunday 11/06/2022, 22:19:20
 * 
 * Image Information
 * -----------------
 * TitleScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREEN_H
#define TITLESCREEN_H

extern const unsigned short TitleScreen[38400];
#define TITLESCREEN_SIZE 76800
#define TITLESCREEN_LENGTH 38400
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160

#endif

