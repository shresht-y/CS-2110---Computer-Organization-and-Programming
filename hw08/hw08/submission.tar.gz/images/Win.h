/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Win Win.png 
 * Time-stamp: Monday 11/07/2022, 18:40:56
 * 
 * Image Information
 * -----------------
 * Win.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_H
#define WIN_H

extern const unsigned short Win[38400];
#define WIN_SIZE 76800
#define WIN_LENGTH 38400
#define WIN_WIDTH 240
#define WIN_HEIGHT 160

#endif

